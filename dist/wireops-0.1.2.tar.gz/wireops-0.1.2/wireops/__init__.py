# wireops/__init__.py

""" Low-level primitives for transmission of compressed data. """

__version__ = '0.1.2'
__version_date__ = '2016-12-16'


__all__ = ['__version__', '__version_date__', ]
