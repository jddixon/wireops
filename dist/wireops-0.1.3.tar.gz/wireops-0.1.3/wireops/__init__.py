# wireops/__init__.py

""" Low-level primitives for transmission of compressed data. """

__version__ = '0.1.3'
__version_date__ = '2017-01-23'


__all__ = ['__version__', '__version_date__', ]
